#!/bin/bash

## SUBMISSION OF THE JOBS ON LEGION/GRACE
##
## Usage: ./queue_jobs.sh [previous_jobid]
## 
## If there are no arguments (i.e. previous_jobid is not provided)  
## the $first job is submitted directly and the following ones are held
## If a previous_jobid is provided, then the $first job will wait for the end of
## the ${previous_jobid} job
##
## Matteo Paloni - 24/08/2016

scriptname=metad   # name of the submission files

first=0  # number of the first submission file
second=$((first+1))
last=20           # number of the last submission file
numlist=$(seq $second 1 $last)

############ JOB SUBMISSION ###############


if [ $# -eq 0 ]; then     # if no previous_pid is provided...

qsub metad_${first}.sh | cat > qsub_out.log # submission of the $first job
jobid=$(awk '{print $3}' qsub_out.log)      # the jobid is stored

echo "$jobid"

for num in $numlist
do

    qsub -hold_jid $jobid metad_$num.sh | cat > qsub_out.log # submission of the other jobs
    jobid=$(awk '{print $3}' qsub_out.log)

    echo "$jobid"

done

elif [ $# -eq 1 ]; then  # else if a previous_pid is provided...

qsub -hold_jid $1 metad_${first}.sh | cat > qsub_out.log # submission of the first job
jobid=$(awk '{print $3}' qsub_out.log)                   # the jobid is stored

echo "$jobid"

for num in $numlist
do

    qsub -hold_jid $jobid metad_$num.sh | cat > qsub_out.log # submission of the other jobs
    jobid=$(awk '{print $3}' qsub_out.log)

    echo "$jobid"

done

fi

