# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 07:01:43 2019

@author: vesi
"""
import numpy as np

no_mols=96
no_atoms=63

for i in range(no_mols):
    f = open( 'plumed%d.dat' % (i), 'w' )
    f.write ("tA: TORSION VECTOR1="+np.str(i*no_atoms+7)+","+np.str(i*no_atoms+1)
    +" AXIS="+np.str(i*no_atoms+1)+","+np.str(i*no_atoms+22)+" VECTOR2="+np.str(i*no_atoms+22)
    +","+np.str(i*no_atoms+28)+"\n")
    
    f.write ("tB: TORSION VECTOR1="+np.str(i*no_atoms+20)+","+np.str(i*no_atoms+9)
    +" AXIS="+np.str(i*no_atoms+9)+","+np.str(i*no_atoms+2)+" VECTOR2="+np.str(i*no_atoms+2)
    +","+np.str(i*no_atoms+30) +"\n")
    
    f.write ("tC: TORSION VECTOR1="+np.str(i*no_atoms+9)+","+np.str(i*no_atoms+2)
    +" AXIS="+np.str(i*no_atoms+2)+","+np.str(i*no_atoms+30)+" VECTOR2="+np.str(i*no_atoms+30)
    +","+np.str(i*no_atoms+42) +"\n")
    
    f.write ("tD: TORSION VECTOR1="+np.str(i*no_atoms+9)+","+np.str(i*no_atoms+18)
    +" AXIS="+np.str(i*no_atoms+18)+","+np.str(i*no_atoms+12)+" VECTOR2="+np.str(i*no_atoms+12)
    +","+np.str(i*no_atoms+5) +"\n")
    
    f.write ("tE: TORSION VECTOR1="+np.str(i*no_atoms+11)+","+np.str(i*no_atoms+15)
    +" AXIS="+np.str(i*no_atoms+15)+","+np.str(i*no_atoms+46)+" VECTOR2="+np.str(i*no_atoms+46)
    +","+np.str(i*no_atoms+61) +"\n")    
    
    f.write ("tF: TORSION VECTOR1="+np.str(i*no_atoms+15)+","+np.str(i*no_atoms+46)
    +" AXIS="+np.str(i*no_atoms+46)+","+np.str(i*no_atoms+61)+" VECTOR2="+np.str(i*no_atoms+61)
    +","+np.str(i*no_atoms+57) +"\n")      
    
    f.write("PRINT ARG=tA,tB,tC,tD,tE,tF FILE=cluster_data_%d" % (i) + "\n")
    f.write("ENDPLUMED")
    
    f.close()
    
    