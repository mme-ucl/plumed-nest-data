All simulations start from state 5, except from aa_2 which starts from state 2.
