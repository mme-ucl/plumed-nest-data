cp ../plumed.dat .

for i in `seq 31 60`
do

cat << EOF > input_$i

temperature 1
tstep 0.005
friction 1
dimension 1
nstep 1000000
ipos `echo $((RANDOM%30)) / 10 - 1.5  | bc -l`
periodic false

EOF


plumed pesmd --plumed plumed.dat < input_$i

mv HILLS HILLS_$i
mv position position_$i

done

