for i in `seq 19  30`
do

cd REWE_FB_$i

cat << EOF > plumed_FB_rewe.dat
p: READ  FILE=../position_$i  VALUES=p.x IGNORE_FORCES IGNORE_TIME

EXTERNAL ARG=p.x FILE=grid.dat LABEL=metad

bias: REWEIGHT_BIAS TEMP=120

HISTOGRAM ...
  ARG=p.x
  GRID_MIN=-2.6
  GRID_MAX=2.6
  GRID_BIN=500
  BANDWIDTH=0.095
  LOGWEIGHTS=bias
  LABEL=hh
... HISTOGRAM

ff: CONVERT_TO_FES GRID=hh TEMP=120 


DUMPGRID GRID=ff FILE=fes STRIDE=500

EOF



plumed driver --plumed plumed_FB_rewe.dat --noatoms

cd ..

done

