for i in `seq 1 30`
do

mkdir REWE_BONOMI_$i

tail -n 2000000 position_$i > COLVAR
tail -n 4000 HILLS_$i > HILLS


#for iteration in `seq 10 10 2000`

#do

#length=`echo 500 \* $iteration | bc -l `  



#head -n $length position > COLVAR
#head -n $iteration hills_temp > HILLS

./reweight -colvar COLVAR -hills HILLS -ncv 1 -nvar 1 -stride 500 -fes 1  -temp 120 -welltemp -bound -2.6 2.6 -ngrid 500 -kjoule -out analysis.fes -fix 1 -rewtype 0 -timeout 500 

mv analysis.fes* REWE_BONOMI_$i

#done

done

