for i in `seq 1 30`
do

mkdir REWE_FB_$i

cd REWE_FB_$i

cat << EOF > plumed_FB.dat
p: READ  FILE=../position_$i  VALUES=p.x IGNORE_FORCES IGNORE_TIME

METAD ... 
ARG=p.x
SIGMA=0.05 
HEIGHT=0.1 
PACE=500 
BIASFACTOR=5 
LABEL=metad 
TEMP=120
GRID_MIN=-2.7
GRID_MAX=2.7
GRID_BIN=500
GRID_WSTRIDE=100000
GRID_WFILE=grid.dat
... METAD


EOF



plumed driver --plumed plumed_FB.dat --noatoms

cd ..

done

