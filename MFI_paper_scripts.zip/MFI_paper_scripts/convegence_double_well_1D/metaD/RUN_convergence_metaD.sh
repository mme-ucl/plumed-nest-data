for i in `seq 1 30`
do

cat << EOF > input_$i

temperature 1
tstep 0.005
friction 1
dimension 1
nstep 2000000
ipos `echo $((RANDOM%30)) / 10 - 1.5  | bc -l`
periodic false

EOF


plumed pesmd --plumed ./plumed_metaD.dat < input_$i

mv HILLS HILLS_$i
mv position position_$i

done

